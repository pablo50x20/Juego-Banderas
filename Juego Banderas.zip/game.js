// ========== GAME DATA ==========
const CONTINENTS = ['AFRICA', 'AMERICA', 'ASIA', 'EUROPA', 'OCEANIA'];

const COUNTRIES = {
  AFRICA: [
    'ANGOLA','ARGELIA','BENIN','BOTSUANA','BURKINA_FASO','BURUNDI','CABO_VERDE',
    'CAMERUN','CHAD','COMORAS','COSTA_DE_MARFIL','EGIPTO','ERITREA','ETIOPIA',
    'GABON','GAMBIA','GHANA','GUINEA','GUINEA_ECUATORIAL','GUINEA_BISAU','KENIA',
    'LESOTO','LIBERIA','LIBIA','MADAGASCAR','MALAUI','MALI','MARRUECOS','MAURICIO',
    'MAURITANIA','MOZAMBIQUE','NAMIBIA','NIGER','NIGERIA','REPUBLICA_CENTROAFRICANA',
    'REPUBLICA_DEL_CONGO','REPUBLICA_DEMOCRATICA_DEL_CONGO','RUANDA',
    'SANTO_TOME_Y_PRINCIPE','SENEGAL','SEYCHELLES','SIERRA_LEONA','SOMALIA',
    'SUDAFRICA','SUDAN','SUDAN_DEL_SUR','TUNEZ','TANZANIA','TOGO','UGANDA',
    'YIBUTI','ZAMBIA','ZIMBABUE'
  ],
  AMERICA: [
    'ANTIGUA_Y_BARBUDA','ARGENTINA','BAHAMAS','BARBADOS','BELICE','BOLIVIA',
    'BRASIL','CANADA','CHILE','COLOMBIA','COSTA_RICA','CUBA','DOMINICA',
    'ECUADOR','EL_SALVADOR','ESTADOS_UNIDOS','GRANADA','GUATEMALA','HAITI',
    'HONDURAS','JAMAICA','MEXICO','NICARAGUA','PANAMA','PARAGUAY','PERU',
    'REPUBLICA_DOMINICANA','SAN_CRISTOBAL_Y_NIEVES','SAN_VICENTE_Y_LAS_GRANADINAS',
    'SANTA_LUCIA','TRINIDAD_Y_TOBAGO','URUGUAY','VENEZUELA'
  ],
  ASIA: [
    'AFGANISTAN','ARABIA_SAUDITA','ARMENIA','AZERBAIYAN','BANGLADESH','BAREIN',
    'BIRMANIA','BRUNEI','BUTAN','CAMBOYA','CATAR','CHINA',
    'COREA_DEL_NORTE','COREA_DEL_SUR','EMIRATOS_ARABES_UNIDOS','FILIPINAS',
    'GEORGIA','INDIA','INDONESIA','IRAN','IRAK','ISRAEL','JAPON','JORDANIA',
    'KAZAJISTAN','KIRGUISTAN','KUWAIT','LAOS','LIBANO','MALASIA','MALDIVAS',
    'MONGOLIA','OMAN','PAKISTAN','PALESTINA','SINGAPUR','SIRIA','SRI_LANKA',
    'TAILANDIA','TAYIKISTAN','TIMOR_ORIENTAL','TURKMENISTAN',
    'UZBEKISTAN','VIETNAM','YEMEN'
  ],
  EUROPA: [
    'ALBANIA','ALEMANIA','ANDORRA','AUSTRIA','BELGICA','BIELORRUSIA','CHIPRE',
    'BOSNIA_Y_HERZEGOVINA','BULGARIA','CIUDAD_DEL_VATICANO','CROACIA',
    'DINAMARCA','ESCOCIA','ESLOVAQUIA','ESLOVENIA','ESPANA','ESTONIA',
    'FINLANDIA','FRANCIA','GALES','GRECIA','HUNGRIA','INGLATERRA','IRLANDA',
    'ISLANDIA','ITALIA','LETONIA','LIECHTENSTEIN','LITUANIA','LUXEMBURGO',
    'MONACO','MACEDONIA_DEL_NORTE','MALTA','MOLDAVIA','MONTENEGRO','NORUEGA',
    'PAISES_BAJOS','POLONIA','PORTUGAL','REPUBLICA_CHECA','RUMANIA','RUSIA',
    'SAN_MARINO','SERBIA','SUECIA','SUIZA','UCRANIA'
  ],
  OCEANIA: [
    'AUSTRALIA','ESTADOS_FEDERADOS_DE_MICRONESIA','FIYI','ISLAS_MARSHALL',
    'ISLAS_SALOMON','KIRIBATI','NAURU','NUEVA_ZELANDA','PALAOS',
    'PAPUA_NUEVA_GUINEA','SAMOA','TONGA','TUVALU','VANUATU'
  ]
};

const DISPLAY_NAMES = {
  // AFRICA
  ANGOLA:'ANGOLA', ARGELIA:'ARGELIA', BENIN:'BENÍN', BOTSUANA:'BOTSUANA',
  BURKINA_FASO:'BURKINA FASO', BURUNDI:'BURUNDI', CABO_VERDE:'CABO VERDE',
  CAMERUN:'CAMERÚN', CHAD:'CHAD', COMORAS:'COMORAS', COSTA_DE_MARFIL:'COSTA DE MARFIL',
  EGIPTO:'EGIPTO', ERITREA:'ERITREA', ETIOPIA:'ETIOPÍA', GABON:'GABÓN',
  GAMBIA:'GAMBIA', GHANA:'GHANA', GUINEA:'GUINEA', GUINEA_ECUATORIAL:'GUINEA ECUATORIAL',
  GUINEA_BISAU:'GUINEA-BISÁU', KENIA:'KENIA', LESOTO:'LESOTO', LIBERIA:'LIBERIA',
  LIBIA:'LIBIA', MADAGASCAR:'MADAGASCAR', MALAUI:'MALAUI', MALI:'MALÍ',
  MARRUECOS:'MARRUECOS', MAURICIO:'MAURICIO', MAURITANIA:'MAURITANIA',
  MOZAMBIQUE:'MOZAMBIQUE', NAMIBIA:'NAMIBIA', NIGER:'NÍGER', NIGERIA:'NIGERIA',
  REPUBLICA_CENTROAFRICANA:'REPÚBLICA CENTROAFRICANA',
  REPUBLICA_DEL_CONGO:'REPÚBLICA DEL CONGO',
  REPUBLICA_DEMOCRATICA_DEL_CONGO:'REPÚBLICA DEMOCRÁTICA DEL CONGO',
  RUANDA:'RUANDA', SANTO_TOME_Y_PRINCIPE:'SANTO TOMÉ Y PRÍNCIPE',
  SENEGAL:'SENEGAL', SEYCHELLES:'SEYCHELLES', SIERRA_LEONA:'SIERRA LEONA',
  SOMALIA:'SOMALIA', SUDAFRICA:'SUDÁFRICA', SUDAN:'SUDÁN', SUDAN_DEL_SUR:'SUDÁN DEL SUR',
  TUNEZ:'TÚNEZ', TANZANIA:'TANZANIA', TOGO:'TOGO', UGANDA:'UGANDA',
  YIBUTI:'YIBUTI', ZAMBIA:'ZAMBIA', ZIMBABUE:'ZIMBABUE',
  // AMERICA
  ANTIGUA_Y_BARBUDA:'ANTIGUA Y BARBUDA', ARGENTINA:'ARGENTINA', BAHAMAS:'BAHAMAS',
  BARBADOS:'BARBADOS', BELICE:'BELICE', BOLIVIA:'BOLIVIA', BRASIL:'BRASIL',
  CANADA:'CANADÁ', CHILE:'CHILE', COLOMBIA:'COLOMBIA', COSTA_RICA:'COSTA RICA',
  CUBA:'CUBA', DOMINICA:'DOMÍNICA', ECUADOR:'ECUADOR', EL_SALVADOR:'EL SALVADOR',
  ESTADOS_UNIDOS:'ESTADOS UNIDOS', GRANADA:'GRANADA', GUATEMALA:'GUATEMALA',
  HAITI:'HAITÍ', HONDURAS:'HONDURAS', JAMAICA:'JAMAICA', MEXICO:'MÉXICO',
  NICARAGUA:'NICARAGUA', PANAMA:'PANAMÁ', PARAGUAY:'PARAGUAY', PERU:'PERÚ',
  REPUBLICA_DOMINICANA:'REPÚBLICA DOMINICANA',
  SAN_CRISTOBAL_Y_NIEVES:'SAN CRISTÓBAL Y NIEVES',
  SAN_VICENTE_Y_LAS_GRANADINAS:'SAN VICENTE Y LAS GRANADINAS',
  SANTA_LUCIA:'SANTA LUCÍA', TRINIDAD_Y_TOBAGO:'TRINIDAD Y TOBAGO',
  URUGUAY:'URUGUAY', VENEZUELA:'VENEZUELA',
  // ASIA
  AFGANISTAN:'AFGANISTÁN', ARABIA_SAUDITA:'ARABIA SAUDITA', ARMENIA:'ARMENIA',
  AZERBAIYAN:'AZERBAIYÁN', BANGLADESH:'BANGLADÉS', BAREIN:'BARÉIN',
  BIRMANIA:'BIRMANIA', BRUNEI:'BRUNÉI', BUTAN:'BUTÁN', CAMBOYA:'CAMBOYA',
  CATAR:'CATAR', CHINA:'CHINA', CHIPRE:'CHIPRE', COREA_DEL_NORTE:'COREA DEL NORTE',
  COREA_DEL_SUR:'COREA DEL SUR', EMIRATOS_ARABES_UNIDOS:'EMIRATOS ÁRABES UNIDOS',
  FILIPINAS:'FILIPINAS', GEORGIA:'GEORGIA', INDIA:'INDIA', INDONESIA:'INDONESIA',
  IRAN:'IRÁN', IRAK:'IRAK', ISRAEL:'ISRAEL', JAPON:'JAPÓN', JORDANIA:'JORDANIA',
  KAZAJISTAN:'KAZAJISTÁN', KIRGUISTAN:'KIRGUISTÁN', KUWAIT:'KUWAIT',
  LAOS:'LAOS', LIBANO:'LÍBANO', MALASIA:'MALASIA', MALDIVAS:'MALDIVAS',
  MONGOLIA:'MONGOLIA', OMAN:'OMÁN', PAKISTAN:'PAKISTÁN', PALESTINA:'PALESTINA',
  SINGAPUR:'SINGAPUR', SIRIA:'SIRIA', SRI_LANKA:'SRI LANKA', TAILANDIA:'TAILANDIA',
  TAYIKISTAN:'TAYIKISTÁN', TIMOR_ORIENTAL:'TIMOR ORIENTAL',
  TURKMENISTAN:'TURKMENISTÁN', UZBEKISTAN:'UZBEKISTÁN',
  VIETNAM:'VIETNAM', YEMEN:'YEMEN',
  // EUROPA
  ALBANIA:'ALBANIA', ALEMANIA:'ALEMANIA', ANDORRA:'ANDORRA', AUSTRIA:'AUSTRIA',
  BELGICA:'BÉLGICA', BIELORRUSIA:'BIELORRUSIA', BOSNIA_Y_HERZEGOVINA:'BOSNIA Y HERZEGOVINA',
  BULGARIA:'BULGARIA', CIUDAD_DEL_VATICANO:'CIUDAD DEL VATICANO', CROACIA:'CROACIA',
  DINAMARCA:'DINAMARCA', ESCOCIA:'ESCOCIA', ESLOVAQUIA:'ESLOVAQUIA',
  ESLOVENIA:'ESLOVENIA', ESPANA:'ESPAÑA', ESTONIA:'ESTONIA', FINLANDIA:'FINLANDIA',
  FRANCIA:'FRANCIA', GALES:'GALES', GRECIA:'GRECIA', HUNGRIA:'HUNGRÍA',
  INGLATERRA:'INGLATERRA', IRLANDA:'IRLANDA', ISLANDIA:'ISLANDIA', ITALIA:'ITALIA',
  LETONIA:'LETONIA', LIECHTENSTEIN:'LIECHTENSTEIN', LITUANIA:'LITUANIA',
  LUXEMBURGO:'LUXEMBURGO', MONACO:'MÓNACO', MACEDONIA_DEL_NORTE:'MACEDONIA DEL NORTE',
  MALTA:'MALTA', MOLDAVIA:'MOLDAVIA', MONTENEGRO:'MONTENEGRO', NORUEGA:'NORUEGA',
  PAISES_BAJOS:'PAÍSES BAJOS', POLONIA:'POLONIA', PORTUGAL:'PORTUGAL',
  REPUBLICA_CHECA:'REPÚBLICA CHECA', RUMANIA:'RUMANIA', RUSIA:'RUSIA',
  SAN_MARINO:'SAN MARINO', SERBIA:'SERBIA', SUECIA:'SUECIA', SUIZA:'SUIZA',
  UCRANIA:'UCRANIA',
  // OCEANIA
  AUSTRALIA:'AUSTRALIA', ESTADOS_FEDERADOS_DE_MICRONESIA:'ESTADOS FEDERADOS DE MICRONESIA',
  FIYI:'FIYI', ISLAS_MARSHALL:'ISLAS MARSHALL', ISLAS_SALOMON:'ISLAS SALOMÓN',
  KIRIBATI:'KIRIBATI', NAURU:'NAURU', NUEVA_ZELANDA:'NUEVA ZELANDA',
  PALAOS:'PALAOS', PAPUA_NUEVA_GUINEA:'PAPÚA NUEVA GUINEA', SAMOA:'SAMOA',
  TONGA:'TONGA', TUVALU:'TUVALU', VANUATU:'VANUATU',
};

// Nombres para lógica del juego (sin tildes, Ñ se mantiene)
const GAME_NAMES = {
  // AFRICA
  ANGOLA:'ANGOLA', ARGELIA:'ARGELIA', BENIN:'BENIN', BOTSUANA:'BOTSUANA',
  BURKINA_FASO:'BURKINA FASO', BURUNDI:'BURUNDI', CABO_VERDE:'CABO VERDE',
  CAMERUN:'CAMERUN', CHAD:'CHAD', COMORAS:'COMORAS', COSTA_DE_MARFIL:'COSTA DE MARFIL',
  EGIPTO:'EGIPTO', ERITREA:'ERITREA', ETIOPIA:'ETIOPIA', GABON:'GABON',
  GAMBIA:'GAMBIA', GHANA:'GHANA', GUINEA:'GUINEA', GUINEA_ECUATORIAL:'GUINEA ECUATORIAL',
  GUINEA_BISAU:'GUINEA-BISAU', KENIA:'KENIA', LESOTO:'LESOTO', LIBERIA:'LIBERIA',
  LIBIA:'LIBIA', MADAGASCAR:'MADAGASCAR', MALAUI:'MALAUI', MALI:'MALI',
  MARRUECOS:'MARRUECOS', MAURICIO:'MAURICIO', MAURITANIA:'MAURITANIA',
  MOZAMBIQUE:'MOZAMBIQUE', NAMIBIA:'NAMIBIA', NIGER:'NIGER', NIGERIA:'NIGERIA',
  REPUBLICA_CENTROAFRICANA:'REPUBLICA CENTROAFRICANA',
  REPUBLICA_DEL_CONGO:'REPUBLICA DEL CONGO',
  REPUBLICA_DEMOCRATICA_DEL_CONGO:'REPUBLICA DEMOCRATICA DEL CONGO',
  RUANDA:'RUANDA', SANTO_TOME_Y_PRINCIPE:'SANTO TOME Y PRINCIPE',
  SENEGAL:'SENEGAL', SEYCHELLES:'SEYCHELLES', SIERRA_LEONA:'SIERRA LEONA',
  SOMALIA:'SOMALIA', SUDAFRICA:'SUDAFRICA', SUDAN:'SUDAN', SUDAN_DEL_SUR:'SUDAN DEL SUR',
  TUNEZ:'TUNEZ', TANZANIA:'TANZANIA', TOGO:'TOGO', UGANDA:'UGANDA',
  YIBUTI:'YIBUTI', ZAMBIA:'ZAMBIA', ZIMBABUE:'ZIMBABUE',
  // AMERICA
  ANTIGUA_Y_BARBUDA:'ANTIGUA Y BARBUDA', ARGENTINA:'ARGENTINA', BAHAMAS:'BAHAMAS',
  BARBADOS:'BARBADOS', BELICE:'BELICE', BOLIVIA:'BOLIVIA', BRASIL:'BRASIL',
  CANADA:'CANADA', CHILE:'CHILE', COLOMBIA:'COLOMBIA', COSTA_RICA:'COSTA RICA',
  CUBA:'CUBA', DOMINICA:'DOMINICA', ECUADOR:'ECUADOR', EL_SALVADOR:'EL SALVADOR',
  ESTADOS_UNIDOS:'ESTADOS UNIDOS', GRANADA:'GRANADA', GUATEMALA:'GUATEMALA',
  HAITI:'HAITI', HONDURAS:'HONDURAS', JAMAICA:'JAMAICA', MEXICO:'MEXICO',
  NICARAGUA:'NICARAGUA', PANAMA:'PANAMA', PARAGUAY:'PARAGUAY', PERU:'PERU',
  REPUBLICA_DOMINICANA:'REPUBLICA DOMINICANA',
  SAN_CRISTOBAL_Y_NIEVES:'SAN CRISTOBAL Y NIEVES',
  SAN_VICENTE_Y_LAS_GRANADINAS:'SAN VICENTE Y LAS GRANADINAS',
  SANTA_LUCIA:'SANTA LUCIA', TRINIDAD_Y_TOBAGO:'TRINIDAD Y TOBAGO',
  URUGUAY:'URUGUAY', VENEZUELA:'VENEZUELA',
  // ASIA
  AFGANISTAN:'AFGANISTAN', ARABIA_SAUDITA:'ARABIA SAUDITA', ARMENIA:'ARMENIA',
  AZERBAIYAN:'AZERBAIYAN', BANGLADESH:'BANGLADESH', BAREIN:'BAREIN',
  BIRMANIA:'BIRMANIA', BRUNEI:'BRUNEI', BUTAN:'BUTAN', CAMBOYA:'CAMBOYA',
  CATAR:'CATAR', CHINA:'CHINA', CHIPRE:'CHIPRE', COREA_DEL_NORTE:'COREA DEL NORTE',
  COREA_DEL_SUR:'COREA DEL SUR', EMIRATOS_ARABES_UNIDOS:'EMIRATOS ARABES UNIDOS',
  FILIPINAS:'FILIPINAS', GEORGIA:'GEORGIA', INDIA:'INDIA', INDONESIA:'INDONESIA',
  IRAN:'IRAN', IRAK:'IRAK', ISRAEL:'ISRAEL', JAPON:'JAPON', JORDANIA:'JORDANIA',
  KAZAJISTAN:'KAZAJISTAN', KIRGUISTAN:'KIRGUISTAN', KUWAIT:'KUWAIT',
  LAOS:'LAOS', LIBANO:'LIBANO', MALASIA:'MALASIA', MALDIVAS:'MALDIVAS',
  MONGOLIA:'MONGOLIA', OMAN:'OMAN', PAKISTAN:'PAKISTAN', PALESTINA:'PALESTINA',
  SINGAPUR:'SINGAPUR', SIRIA:'SIRIA', SRI_LANKA:'SRI LANKA', TAILANDIA:'TAILANDIA',
  TAYIKISTAN:'TAYIKISTAN', TIMOR_ORIENTAL:'TIMOR ORIENTAL',
  TURKMENISTAN:'TURKMENISTAN', UZBEKISTAN:'UZBEKISTAN',
  VIETNAM:'VIETNAM', YEMEN:'YEMEN',
  // EUROPA
  ALBANIA:'ALBANIA', ALEMANIA:'ALEMANIA', ANDORRA:'ANDORRA', AUSTRIA:'AUSTRIA',
  BELGICA:'BELGICA', BIELORRUSIA:'BIELORRUSIA', BOSNIA_Y_HERZEGOVINA:'BOSNIA Y HERZEGOVINA',
  BULGARIA:'BULGARIA', CIUDAD_DEL_VATICANO:'CIUDAD DEL VATICANO', CROACIA:'CROACIA',
  DINAMARCA:'DINAMARCA', ESCOCIA:'ESCOCIA', ESLOVAQUIA:'ESLOVAQUIA',
  ESLOVENIA:'ESLOVENIA', ESPANA:'ESPAÑA', ESTONIA:'ESTONIA', FINLANDIA:'FINLANDIA',
  FRANCIA:'FRANCIA', GALES:'GALES', GRECIA:'GRECIA', HUNGRIA:'HUNGRIA',
  INGLATERRA:'INGLATERRA', IRLANDA:'IRLANDA', ISLANDIA:'ISLANDIA', ITALIA:'ITALIA',
  LETONIA:'LETONIA', LIECHTENSTEIN:'LIECHTENSTEIN', LITUANIA:'LITUANIA',
  LUXEMBURGO:'LUXEMBURGO', MONACO:'MONACO', MACEDONIA_DEL_NORTE:'MACEDONIA DEL NORTE',
  MALTA:'MALTA', MOLDAVIA:'MOLDAVIA', MONTENEGRO:'MONTENEGRO', NORUEGA:'NORUEGA',
  PAISES_BAJOS:'PAISES BAJOS', POLONIA:'POLONIA', PORTUGAL:'PORTUGAL',
  REPUBLICA_CHECA:'REPUBLICA CHECA', RUMANIA:'RUMANIA', RUSIA:'RUSIA',
  SAN_MARINO:'SAN MARINO', SERBIA:'SERBIA', SUECIA:'SUECIA', SUIZA:'SUIZA',
  UCRANIA:'UCRANIA',
  // OCEANIA
  AUSTRALIA:'AUSTRALIA', ESTADOS_FEDERADOS_DE_MICRONESIA:'ESTADOS FEDERADOS DE MICRONESIA',
  FIYI:'FIYI', ISLAS_MARSHALL:'ISLAS MARSHALL', ISLAS_SALOMON:'ISLAS SALOMON',
  KIRIBATI:'KIRIBATI', NAURU:'NAURU', NUEVA_ZELANDA:'NUEVA ZELANDA',
  PALAOS:'PALAOS', PAPUA_NUEVA_GUINEA:'PAPUA NUEVA GUINEA', SAMOA:'SAMOA',
  TONGA:'TONGA', TUVALU:'TUVALU', VANUATU:'VANUATU',
};

const ALPHABET = 'ABCDEFGHIJKLMNÑOPQRSTUVWXYZ'.split('');
const QWERTY_ROWS = ['QWERTYUIOP', 'ASDFGHJKL', 'ZXCVBNMÑ'];

// ========== ESTADO ==========
let musicOn = true, sfxOn = true;
let currentContinent = 0;
let currentCountryKey = '';
let currentGameName = '';
let score = 0;
let blockLetters = [], blockVisible = [];
let brightBlock = 0, brightInterval = null, animRunning = false;
let waitingYesNo = false, currentRevealedLetter = '', guessMode = false;
let correctLetters = new Set(), wrongLetters = new Set();
let savedScores = {};

// ========== AUDIO ==========
let noteIndex = 0;
let audioCtx = null;
let noteBuffers = [];
let errorBuffer = null;
let audioReady = false;
let audioDecoding = false;

function initAudio() {}  // setup happens on first user gesture

function decodeBase64(src) {
  const base64 = src.split(',')[1];
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

async function setupAudio() {
  if (audioReady || audioDecoding || !window.AUDIO_DATA) return;
  audioDecoding = true;
  try {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') await audioCtx.resume();
    noteBuffers = await Promise.all(
      AUDIO_DATA.notas.map(src => audioCtx.decodeAudioData(decodeBase64(src)))
    );
    errorBuffer = await audioCtx.decodeAudioData(decodeBase64(AUDIO_DATA.error));
    audioReady = true;
  } catch(e) {
    audioDecoding = false;
  }
}

function playBuffer(buffer) {
  if (!audioCtx || !buffer) return;
  if (audioCtx.state === 'suspended') { audioCtx.resume().then(() => playBuffer(buffer)); return; }
  const src = audioCtx.createBufferSource();
  src.buffer = buffer;
  src.connect(audioCtx.destination);
  src.start(0);
}

async function playNote() {
  if (!sfxOn) return;
  if (!audioReady) { await setupAudio(); }
  if (!audioReady) return;
  playBuffer(noteBuffers[noteIndex % noteBuffers.length]);
  noteIndex++;
}

async function playError() {
  if (!sfxOn) return;
  if (!audioReady) { await setupAudio(); }
  if (!audioReady) return;
  playBuffer(errorBuffer);
  noteIndex = 0;
}

function resetNotes() { noteIndex = 0; }
let selectedContinents = new Set(['AFRICA','AMERICA','ASIA','EUROPA','OCEANIA']); // todos por defecto
let filteredMode = false; // true cuando se juega desde pantalla 5

// ========== INICIO ==========
window.addEventListener('load', () => {
  loadSavedScores();
  document.getElementById('logo-img').src = IMAGES.LOGO;
  buildQwerty();
  initAudio();
  goScreen(1);
  document.getElementById('btn-music').addEventListener('click', toggleMusic);
  document.getElementById('btn-sfx').addEventListener('click', toggleSFX);
});

function loadSavedScores() {
  try { const s = localStorage.getItem('quizbanderas_scores'); if (s) savedScores = JSON.parse(s); }
  catch (e) { savedScores = {}; }
}
function saveScores() { localStorage.setItem('quizbanderas_scores', JSON.stringify(savedScores)); }
function scoreKey(continent, country) { return continent + '/' + country; }

// ========== NAVEGACIÓN ==========
function goScreen(n) {
  setupAudio();  // cada navegación es un gesto del usuario
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('screen' + n).classList.add('active');
  document.getElementById('sound-bar').style.display = (n === 1) ? 'none' : 'flex';
  if (n === 4) renderScreen4();
  if (n === 5) renderScreen5();
}

// ========== SONIDO ==========
function toggleMusic() { musicOn = !musicOn; updateSoundUI(); }
function toggleSFX()   { sfxOn   = !sfxOn;   updateSoundUI(); }
function updateSoundUI() {
  document.getElementById('s1-music').textContent = '🎵 Música: ' + (musicOn ? 'ON' : 'OFF');
  document.getElementById('s1-sfx').textContent   = '🔔 Sonidos: ' + (sfxOn  ? 'ON' : 'OFF');
  document.getElementById('btn-music').classList.toggle('off', !musicOn);
  document.getElementById('btn-sfx').classList.toggle('off', !sfxOn);
}

// ========== INICIO PARTIDA ==========
function startGame() {
  // Siempre usa todos los continentes (botón JUGAR de pantalla 2)
  filteredMode = false;
  playFromPool(CONTINENTS);
}

function isContinentCompleted(c) {
  return COUNTRIES[c].every(k => savedScores[scoreKey(c, k)] !== undefined);
}

function startGameFiltered() {
  if (selectedContinents.size === 0) { showToast('⚠️ Elige al menos un continente'); return; }
  filteredMode = true;
  playFromPool([...selectedContinents]);
}

function playFromPool(continentList) {
  const all = [];
  for (const c of continentList) for (const k of COUNTRIES[c]) all.push({ continent: c, key: k });
  const unplayed = all.filter(x => savedScores[scoreKey(x.continent, x.key)] === undefined);
  if (unplayed.length === 0) {
    if (filteredMode) {
      showToast('🏆 ¡Completaste todos los países seleccionados!');
    } else {
      showToast('🏆 ¡Completaste todas las banderas!');
    }
    goScreen(4);
    return;
  }
  const pick = unplayed[Math.floor(Math.random() * unplayed.length)];
  loadRound(pick.continent, pick.key);
}

function nextFlag() {
  document.getElementById('modal-overlay').classList.remove('visible');
  if (filteredMode) startGameFiltered();
  else startGame();
}

function loadRound(continent, countryKey) {
  currentContinent  = CONTINENTS.indexOf(continent);
  currentCountryKey = countryKey;
  currentGameName   = GAME_NAMES[countryKey];
  score = 1000;
  correctLetters = new Set(); wrongLetters = new Set();
  resetNotes();
  guessMode = false; waitingYesNo = false; currentRevealedLetter = '';

  document.getElementById('flag-img').src = IMAGES[continent][countryKey];
  document.getElementById('continent-label-value').textContent = continent;
  buildBlocks(); buildNameBoxes();
  document.getElementById('score-display').textContent = '1000';
  document.getElementById('letter-panel').classList.remove('visible');
  document.getElementById('qwerty-panel').classList.remove('visible');
  document.getElementById('discarded-letters').innerHTML = '';
  document.getElementById('action-row').style.display = '';
  document.getElementById('btn-stop').disabled  = false;
  document.getElementById('btn-guess').disabled = false;
  document.getElementById('screen3').classList.remove('guess-mode');
  document.getElementById('screen3').style.paddingBottom = '';
  document.removeEventListener('keydown', handlePhysicalKey);
  resetQwertyKeys();
  startBrightAnimation();
  goScreen(3);
}

// ========== BLOQUES ==========
function buildBlocks() {
  const pool = [...ALPHABET, 'GOOD', 'BAD', null];
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  blockLetters = pool;
  blockVisible = new Array(30).fill(false);
  blockVisible[blockLetters.indexOf(null)] = true;
  renderBlocks();
}

function renderBlocks() {
  const overlay = document.getElementById('blocks-overlay');
  overlay.innerHTML = '';
  for (let i = 0; i < 30; i++) {
    const div = document.createElement('div');
    div.className = 'block' + (blockVisible[i] ? ' hidden' : '');
    div.id = 'block-' + i;
    overlay.appendChild(div);
  }
}

function startBrightAnimation() {
  if (brightInterval) clearInterval(brightInterval);
  animRunning = true;
  brightBlock = randomHiddenBlock();
  updateBright();
  brightInterval = setInterval(() => {
    if (!animRunning) return;
    const next = randomHiddenBlock();
    if (next === -1) { stopAnimation(); return; }
    brightBlock = next;
    updateBright();
  }, 100);
}

function randomHiddenBlock() {
  const hidden = [];
  for (let i = 0; i < 30; i++) { if (!blockVisible[i]) hidden.push(i); }
  return hidden.length === 0 ? -1 : hidden[Math.floor(Math.random() * hidden.length)];
}

function updateBright() {
  document.querySelectorAll('.block').forEach((b, i) => {
    if (!blockVisible[i]) b.classList.toggle('bright', i === brightBlock);
  });
}

function stopAnimation() {
  animRunning = false;
  if (brightInterval) clearInterval(brightInterval);
  brightInterval = null;
  // Quitar el brillo de todos los bloques
  document.querySelectorAll('.block').forEach(b => b.classList.remove('bright'));
}

// ========== BOTÓN STOP ==========
function pressStop() {
  if (!animRunning || waitingYesNo) return;
  stopAnimation();
  const idx = brightBlock;
  blockVisible[idx] = true;
  document.getElementById('block-' + idx)?.classList.add('hidden');
  const assignment = blockLetters[idx];

  if (assignment === 'GOOD') { addJokerBadge('⭐','green'); handleGoodJoker(); restartIfPossible(); return; }
  if (assignment === 'BAD')  { addJokerBadge('💀','red'); changeScore(-100); playError(); showToast('💀 ¡Comodín Malo! -100 pts'); restartIfPossible(); return; }
  if (assignment === null)   { restartIfPossible(); return; }

  const letter = assignment;
  if (correctLetters.has(letter)) { restartIfPossible(); return; }
  if (wrongLetters.has(letter)) {
    if (currentGameName.includes(letter)) { wrongLetters.delete(letter); addCorrectLetter(letter); checkWin(); if (!isGameOver()) restartIfPossible(); }
    else { restartIfPossible(); }
    return;
  }

  currentRevealedLetter = letter;
  document.getElementById('revealed-letter').textContent = letter;
  document.getElementById('letter-panel').classList.add('visible');
  waitingYesNo = true;
  document.getElementById('btn-stop').disabled  = true;
  document.getElementById('btn-guess').disabled = true;
}

function restartIfPossible() {
  if (blockVisible.every(v => v)) { document.getElementById('btn-stop').disabled = true; return; }
  if (!guessMode) {
    startBrightAnimation();
    document.getElementById('btn-stop').disabled  = false;
    document.getElementById('btn-guess').disabled = false;
  }
}

// ========== SÍ / NO ==========
function answerYesNo(userSaidYes) {
  if (!waitingYesNo) return;
  waitingYesNo = false;
  document.getElementById('letter-panel').classList.remove('visible');
  const letter = currentRevealedLetter;
  const inName = currentGameName.includes(letter);
  if      ( userSaidYes &&  inName) { addCorrectLetter(letter); }
  else if ( userSaidYes && !inName) { changeScore(-100); addWrongLetter(letter, 'red'); }
  else if (!userSaidYes &&  inName) { changeScore(-100); addCorrectLetter(letter, true); }
  else                              { addWrongLetter(letter, 'green'); }
  checkWin();
  if (!isGameOver()) restartIfPossible();
}

// ========== LETRAS ==========
function addCorrectLetter(letter, penalized = false) {
  correctLetters.add(letter);
  if (!penalized) playNote(); else playError();
  const boxes = document.querySelectorAll('.word-group .letter-box:not(.hyphen)');
  let boxIdx = 0;
  for (let i = 0; i < currentGameName.length; i++) {
    if (currentGameName[i] === ' ' || currentGameName[i] === '-') continue;
    if (currentGameName[i] === letter) { boxes[boxIdx].textContent = letter; boxes[boxIdx].classList.add(penalized ? 'wrong' : 'correct'); }
    boxIdx++;
  }
  const key = document.querySelector(`.qkey[data-letter="${letter}"]`);
  if (key) { key.disabled = true; key.classList.add('used-correct'); }
}

function addWrongLetter(letter, color) {
  wrongLetters.add(letter);
  if (color === 'green') playNote(); else playError();
  const disc = document.getElementById('discarded-letters');
  const span = document.createElement('span');
  span.className = 'disc-letter ' + color;
  span.textContent = letter;
  disc.appendChild(span);
  const key = document.querySelector(`.qkey[data-letter="${letter}"]`);
  if (key) { key.disabled = true; key.classList.add('used-wrong'); }
}

function addJokerBadge(emoji, color) {
  const disc = document.getElementById('discarded-letters');
  const span = document.createElement('span');
  span.className = 'disc-letter ' + color;
  span.textContent = emoji;
  disc.appendChild(span);
}

function handleGoodJoker() {
  const remaining = [];
  for (const c of currentGameName) { if (c !== ' ' && c !== '-' && !correctLetters.has(c)) remaining.push(c); }
  if (remaining.length === 0) return;
  const pick = remaining[Math.floor(Math.random() * remaining.length)];
  addCorrectLetter(pick);
  checkWin();
  // Show popup with close button
  document.getElementById('joker-letter').textContent = pick;
  document.getElementById('joker-overlay').classList.add('visible');
}

function changeScore(delta) {
  score = Math.max(0, score + delta);
  const el = document.getElementById('score-display');
  el.textContent = score;
  if (delta < 0) { el.classList.remove('score-hit'); void el.offsetWidth; el.classList.add('score-hit'); }
}

function buildNameBoxes() {
  const container = document.getElementById('name-boxes');
  container.innerHTML = '';

  const words = currentGameName.split(' ');
  // Count only real letters (exclude hyphen and space)
  const totalLetters = currentGameName.replace(/[ -]/g, '').length;

  // Multi-line: total letters >= 10 AND more than one word (split by space)
  const multiLine = totalLetters >= 10 && words.length > 1;

  // Split into lines optimally
  function splitIntoLines(words) {
    const n = words.length;
    // Names with 4+ words and 20+ letters: try 3 lines
    const totalL = words.join('').length;
    if (n >= 4 && totalL >= 20) {
      // Try all ways to split into 3 groups
      let best3 = null, bestScore3 = Infinity;
      for (let a = 1; a < n - 1; a++) {
        for (let b = a + 1; b < n; b++) {
          const l1 = words.slice(0, a).join(' ').replace(/ /g,'').length;
          const l2 = words.slice(a, b).join(' ').replace(/ /g,'').length;
          const l3 = words.slice(b).join(' ').replace(/ /g,'').length;
          const score = Math.max(l1,l2,l3) - Math.min(l1,l2,l3);
          if (score < bestScore3) {
            bestScore3 = score;
            best3 = [words.slice(0,a).join(' '), words.slice(a,b).join(' '), words.slice(b).join(' ')];
          }
        }
      }
      return best3;
    }
    // Default: 2 lines
    let best = null, bestScore = Infinity;
    for (let split = 1; split < n; split++) {
      const line1 = words.slice(0, split).join(' ');
      const line2 = words.slice(split).join(' ');
      const len1 = line1.replace(/ /g, '').length;
      const len2 = line2.replace(/ /g, '').length;
      const score = Math.abs(len1 - len2) + Math.max(0, 3 - Math.min(len1, len2)) * 2;
      if (score < bestScore) { bestScore = score; best = [line1, line2]; }
    }
    return best;
  }

  const lineGroups = multiLine ? splitIntoLines(words) : [currentGameName];

  // Calculate dynamic box size based on longest line
  const maxLineLetters = lineGroups.reduce((max, line) => {
    const l = line.replace(/[ -]/g, '').length;
    return l > max ? l : max;
  }, 0);
  const availableWidth = Math.min(window.innerWidth - 40, 520);
  const gaps = (maxLineLetters - 1) * 4;
  const boxSize = Math.max(20, Math.min(38, Math.floor((availableWidth - gaps) / maxLineLetters)));

  lineGroups.forEach(lineText => {
    const group = document.createElement('div');
    group.className = 'word-group';
    for (const c of lineText) {
      if (c === ' ') {
        const sp = document.createElement('div');
        sp.className = 'word-space';
        group.appendChild(sp);
      } else if (c === '-') {
        const hyph = document.createElement('div');
        hyph.className = 'letter-box hyphen';
        hyph.style.cssText = `width:${boxSize}px;height:${boxSize}px;font-size:${Math.round(boxSize*0.6)}px`;
        hyph.textContent = '-';
        group.appendChild(hyph);
      } else {
        const box = document.createElement('div');
        box.className = 'letter-box';
        box.style.cssText = `width:${boxSize}px;height:${boxSize}px;font-size:${Math.round(boxSize*0.6)}px`;
        group.appendChild(box);
      }
    }
    container.appendChild(group);
  });
}

function isGameOver() {
  for (const c of currentGameName) { if (c !== ' ' && c !== '-' && !correctLetters.has(c)) return false; }
  return true;
}

function checkWin() {
  if (!isGameOver()) return;
  stopAnimation();
  savedScores[scoreKey(CONTINENTS[currentContinent], currentCountryKey)] = score;
  saveScores();
  setTimeout(showWinModal, 500);
}

function showWinModal() {
  const continent = CONTINENTS[currentContinent];
  document.getElementById('modal-flag').src             = IMAGES[continent][currentCountryKey];
  document.getElementById('modal-country').textContent  = DISPLAY_NAMES[currentCountryKey];
  document.getElementById('modal-score-val').textContent = score;
  document.getElementById('modal-overlay').classList.add('visible');
}

// ========== MODO ADIVINAR ==========
function enterGuessMode() {
  guessMode = true; stopAnimation();
  document.getElementById('action-row').style.display = 'none';
  document.getElementById('letter-panel').classList.remove('visible');
  document.getElementById('qwerty-panel').classList.add('visible');
  document.getElementById('screen3').classList.add('guess-mode');
  // Add bottom padding so content isn't hidden behind fixed qwerty
  setTimeout(() => {
    const qh = document.getElementById('qwerty-panel').offsetHeight;
    document.getElementById('screen3').style.paddingBottom = qh + 'px';
  }, 50);
  // Enable physical keyboard input
  document.addEventListener('keydown', handlePhysicalKey);
}

function handlePhysicalKey(e) {
  if (!guessMode) return;
  const letter = e.key.toUpperCase();
  // Only handle single letters in the Spanish alphabet
  if (!/^[A-ZÁÉÍÓÚÜÑ]$/.test(letter)) return;
  // Normalize accented vowels to plain (game uses unaccented names)
  const normalized = letter
    .replace('Á','A').replace('É','E').replace('Í','I')
    .replace('Ó','O').replace('Ú','U').replace('Ü','U');
  pressQKey(normalized);
}

function buildQwerty() {
  ['qrow1','qrow2','qrow3'].forEach((rowId, ri) => {
    const el = document.getElementById(rowId);
    el.innerHTML = '';
    for (const letter of QWERTY_ROWS[ri]) {
      const btn = document.createElement('button');
      btn.className = 'qkey'; btn.textContent = letter; btn.dataset.letter = letter;
      btn.addEventListener('click', () => pressQKey(letter));
      el.appendChild(btn);
    }
  });
}

function resetQwertyKeys() {
  document.querySelectorAll('.qkey').forEach(k => { k.disabled = false; k.classList.remove('used-correct','used-wrong'); });
}

function pressQKey(letter) {
  if (correctLetters.has(letter) || wrongLetters.has(letter)) return;
  if (currentGameName.includes(letter)) {
    addCorrectLetter(letter);
    revealBlockForLetter(letter);
  } else {
    changeScore(-100);
    addWrongLetter(letter, 'red');
  }
  checkWin();
}

function revealBlockForLetter(letter) {
  // Find a hidden block assigned to this letter and remove it
  for (let i = 0; i < blockLetters.length; i++) {
    if (blockLetters[i] === letter && !blockVisible[i]) {
      blockVisible[i] = true;
      const el = document.getElementById('block-' + i);
      if (el) el.classList.add('hidden');
      break;
    }
  }
}

// ========== PANTALLA 5: Elegir Continentes ==========
const CONTINENT_META = {
  AFRICA:  { emoji: '🌍', label: 'ÁFRICA' },
  AMERICA: { emoji: '🌎', label: 'AMÉRICA' },
  ASIA:    { emoji: '🌏', label: 'ASIA' },
  EUROPA:  { emoji: '🏰', label: 'EUROPA' },
  OCEANIA: { emoji: '🌊', label: 'OCEANÍA' },
};

function renderScreen5() {
  const container = document.getElementById('continent-checkboxes');
  container.innerHTML = '';
  for (const c of CONTINENTS) {
    const meta      = CONTINENT_META[c];
    const count     = COUNTRIES[c].length;
    const completed = isContinentCompleted(c);
    const isSelected = !completed && selectedContinents.has(c);
    const div = document.createElement('div');
    div.className = 'continent-option' + (isSelected ? ' selected' : '') + (completed ? ' completed' : '');
    div.innerHTML = `
      <span class="c-emoji">${meta.emoji}</span>
      <span class="c-label">${meta.label}</span>
      <span class="c-count">${completed ? '✅ Completado' : count + ' países'}</span>
      <span class="c-check">${completed ? '🏆' : isSelected ? '✓' : ''}</span>
    `;
    if (!completed) div.addEventListener('click', () => toggleContinent(c));
    container.appendChild(div);
  }
}

function toggleContinent(c) {
  if (isContinentCompleted(c)) return;
  if (selectedContinents.has(c)) { selectedContinents.delete(c); }
  else { selectedContinents.add(c); }
  renderScreen5();
}

function selectAllContinents() {
  CONTINENTS.forEach(c => selectedContinents.add(c));
  renderScreen5();
}

function clearAllContinents() {
  selectedContinents.clear();
  renderScreen5();
}

// ========== PANTALLA 4 ==========
function renderScreen4() {
  const continent = CONTINENTS[currentContinent];
  document.getElementById('continent-name').textContent = continent;
  const total = COUNTRIES[continent].length;
  const played = COUNTRIES[continent].filter(k => savedScores[scoreKey(continent, k)] !== undefined).length;
  document.getElementById('continent-progress').textContent = played + ' / ' + total + ' países';
  const list = document.getElementById('countries-list');
  list.innerHTML = '';
  [...COUNTRIES[continent]].sort().forEach((k, idx) => {
    const key = scoreKey(continent, k), played = savedScores[key] !== undefined;
    const row = document.createElement('div');
    row.className = 'country-row ' + (played ? 'played' : 'locked');
    row.innerHTML = played
      ? `<span class="c-num">${idx+1}.</span>
         <span class="c-name">${DISPLAY_NAMES[k]}</span>
         <span class="c-score">${savedScores[key]} pts</span>`
      : `<span class="c-num">${idx+1}.</span>
         <span class="c-lock" style="flex:1; text-align:center;">🔒</span>`;
    if (played) row.addEventListener('click', () => showCountryInfo(k, continent));
    list.appendChild(row);
  });
}

function changeContinent(dir) {
  currentContinent = (currentContinent + dir + CONTINENTS.length) % CONTINENTS.length;
  renderScreen4();
}

// Helper para botón "Jugar Siguiente Bandera" en pantalla 4
function nextRound() {
  if (filteredMode) startGameFiltered();
  else startGame();
}

// ========== INFO DE PAÍS ==========
function showCountryInfo(countryKey, continent) {
  const info = COUNTRY_INFO[countryKey];
  if (!info) return;
  document.getElementById('ci-flag').src     = IMAGES[continent][countryKey];
  document.getElementById('ci-name').textContent      = DISPLAY_NAMES[countryKey];
  document.getElementById('ci-capital').textContent   = info.capital;
  document.getElementById('ci-idioma').textContent    = info.idioma;
  document.getElementById('ci-superficie').textContent = info.superficie + ' km²';
  document.getElementById('ci-poblacion').textContent = info.poblacion;
  document.getElementById('ci-moneda').textContent    = info.moneda;
  document.getElementById('ci-prefijo').textContent   = info.prefijo;
  document.getElementById('ci-score').textContent     = savedScores[scoreKey(continent, countryKey)] + ' pts';
  document.getElementById('country-info-overlay').classList.add('visible');
}

function closeCountryInfo() {
  document.getElementById('country-info-overlay').classList.remove('visible');
}

// ========== MODAL CONTINENTE COMPLETADO ==========
function showContinentCompleteModal(continent) {
  const meta = CONTINENT_META[continent];
  document.getElementById('cc-continent-name').textContent = meta.emoji + ' ' + meta.label;
  document.getElementById('continent-complete-overlay').classList.add('visible');
}

function closeContinentComplete() {
  document.getElementById('continent-complete-overlay').classList.remove('visible');
}

function ccChooseContinent() {
  closeContinentComplete();
  goScreen(5);
}

function ccRandomFlag() {
  closeContinentComplete();
  filteredMode = false;
  startGame();
}

function ccExit() {
  closeContinentComplete();
  goScreen(2);
}

// ========== TOAST ==========
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2500);
}